# Xbox 360 game GPDs

One clean `<TitleID>.gpd` per Xbox 360 / GFWL title (2,820 files), listed in `index.json`
(titleId, name, achievements, gamerscore, source). Used by the Xbox 360 Game Adder.

Sources (se7ensins thread "Xbox 360 GPD Collection", 1652569):
- `2020-02-29.7z`: 2,691 GPDs, all clean (no unlocked achievements). Used as is.
- `2819 GPDs (ALL ADDABLE + CLEANED).7z` (Fadexz, Sep 2021): not clean, so only the 129 titles
  missing from the 2020 pack were taken, with every unlocked achievement reset
  (flags 0x30000 cleared, unlock time 0).

Checked: every file has an XDBF header, no duplicate title IDs, 0 unlocked achievements.
Some entries are apps (no achievements), GFWL or demo titles. Most GPDs carry no achievement icons.

Private: contains publisher achievement text and images. Do not publish.
